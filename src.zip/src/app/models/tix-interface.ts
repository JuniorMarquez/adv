export interface TixInterface{
	id?:string;
	titulo?:string;
	descripcion?:string;
	precio?:string;
	productName?:string;
	description?:string;
	images?: Array<string>;
	notes?:string;
}