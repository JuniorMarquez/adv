import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-affiliate-detail',
  templateUrl: './affiliate-detail.component.html',
  styleUrls: ['./affiliate-detail.component.css']
})
export class AffiliateDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
