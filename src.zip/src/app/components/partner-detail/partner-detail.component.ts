import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partner-detail',
  templateUrl: './partner-detail.component.html',
  styleUrls: ['./partner-detail.component.css']
})
export class PartnerDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
