import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-footer',
  templateUrl: './pre-footer.component.html',
  styleUrls: ['./pre-footer.component.css']
})
export class PreFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
