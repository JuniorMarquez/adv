import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sideleft',
  templateUrl: './sideleft.component.html',
  styleUrls: ['./sideleft.component.css']
})
export class SideleftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
