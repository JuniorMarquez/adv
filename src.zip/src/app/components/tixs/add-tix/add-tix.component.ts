import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tix',
  templateUrl: './add-tix.component.html',
  styleUrls: ['./add-tix.component.css']
})
export class AddTixComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
